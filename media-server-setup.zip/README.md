Setup Plex, radarr, sonarr and bazarr automatically in containers.
Plex UI can be found from http://localhost:30080/web

Usage:
Edit media-server.env
```
# chmod +x setup.sh
# sudo ./setup.sh start
```
Change owner of $BASE_DIR for user installing

```
# sudo chown replace_with_user:replace_with_group -R /opt/media-server
```
Stop and start containers
```
# sudo ./setup.sh stop; sudo ./setup.sh start
```


![Sabnzbd](https://avatars.githubusercontent.com/u/960698?s=48&v=4)Configure sabnzbd 
-----------------
1. Open http://localhost:30084/  
2. Add your news provider
3. Copy API key from "General" tab
4. Configure username and password
5. Go to "Category" and click "save" on "tv" category
6. Change "Folders->Temporary Download Folder" to "/incomplete"
7. Change "Folders->Completed Download Folder" to "/downloads"
8. Add "sabnzbd" (with comma separated) to Special->host_whitelist


![Sonarr](https://avatars.githubusercontent.com/u/1082903?s=48&v=4)Configure sonarr 
----------------

1. Open http://localhost:30081/
2. Setup authentication:
   * Method: Forms
   * Authentication required: Enabled
   * Set username & password
   * Save
3. Open Settings, Media management
   * Add root folder: /storage/tv
4. Setup download client
   * Click "plus"
   * Add sabnzbd
   * Hostname sabnzbd and port 8080
   * Fill APIkey, username and password from sabnzbd
   * Test and save
5. Setup indexer
   * Click "plus"
   * Choose from newznab presets your indexer and configure

6. Store API key from Settings->General
  
![Radarr](https://avatars.githubusercontent.com/u/25025331?s=48&v=4)Configure radarr 
----------------

1. Open http://localhost:30082/
2. Setup authentication:
   * Method: Forms
   * Authentication required: Enabled
   * Set username & password
   * Save
3. Open Settings, Media management
   * Add root folder: /storage/movies
4. Setup download client
   * Click "plus"
   * Add sabnzbd
   * Hostname sabnzbd and port 8080
   * Fill APIkey, username and password from sabnzbd
   * Test and save
5. Setup indexer
   * Click "plus"
   * Choose from newznab presets your indexer and configure
6. Store API key for later use from Settings->General
     
![Bazarr](https://avatars.githubusercontent.com/u/44780843?s=200&v=4)Configure bazarr 
----------------

1. Open http://localhost:30083/
2. Configure Sonarr from Settings -> Sonarr
    * Enable
    * Address "sonarr"
    * Port 8989
    * Add Sonarr API key
3. Click Test, and Save from top of the page
4. Configure Radarr from Settings -> Radarr
    * Enable
    * Address "radarr"
    * Port 7878
    * Add Radarr API key
5. Click Test, and Save from top of the page
6. Choose languages for subtitles
    * Settings -> Languages -> Choose languages
    * Save from top of the page

![Plex](https://avatars.githubusercontent.com/u/324832?s=200&v=4)Configure plex 
---------------
1. Open http://localhost:30080/web/
2. Login with existing Plex account or create new
3. Give a name for your server, click next
4. Add Library, type Movie, click next
5. Browse to "movies" folder and add
6. Add Library, type TV Shows, click next
7. Browse to "tv" and add
8. Click next and done


![overseerr](https://overseerr.dev/_next/image?url=%2Fos_logo_filled.svg&w=96&q=75)Configure overseerr 
-------------------
1. Open http://localhost:30085/
2. Login with existing Plex account 
3. Add plex server with address "plex" and port 32400, save changes
4. Enable "Movies" and "TV Shows" libraries
5. Click start scan and click Continue
6. Add radarr server
    * Select default server
    * Set any server name
    * hostname "radarr"
    * Port 7878
    * API Key from radarr
7. Click Test
8. Choose quality profile as "Any"
9. Set root Folder to "/storage/movies"
10. Click "Add server"
11. Add Sonarr server
    * Select default server
    * Set any server name
    * Hostname "sonarr"
    * Port 8989
    * API key from sonarr 
12. Click test
13. Choose quality profile as "Any"
14. Select root folder to "/storage/tv"
15. Select language profile as "Deprecated"
16. Click "Add Server"
17. Click "Finish setup"


![jellyseerr](https://github.com/Fallenbagel/jellyseerr/raw/develop/public/logo_stacked.svg)Configure jellyseerr 
--------------------
Jellyseerr is a fork of Overseerr with additional features and improved performance. You can use either Overseerr or Jellyseerr (or both for different purposes).

1. Open http://localhost:30087/
2. Login with existing Plex account (or create a local account)
3. Add plex server with address "plex" and port 32400, save changes
4. Enable "Movies" and "TV Shows" libraries
5. Click start scan and click Continue
6. Add radarr server
    * Select default server
    * Set any server name
    * hostname "radarr"
    * Port 7878
    * API Key from radarr
7. Click Test
8. Choose quality profile as "Any"
9. Set root Folder to "/storage/movies"
10. Click "Add server"
11. Add Sonarr server
    * Select default server
    * Set any server name
    * Hostname "sonarr"
    * Port 8989
    * API key from sonarr 
12. Click test
13. Choose quality profile as "Any"
14. Select root folder to "/storage/tv"
15. Select language profile as "Deprecated"
16. Click "Add Server"
17. Click "Finish setup"

**Jellyseerr Additional Features:**
- Enhanced mobile interface
- Better performance and stability
- Additional notification options
- Improved user management
- More customization options


![Watchtower](https://github.com/containrrr/watchtower/blob/main/logo.png?raw=true)Watchtower - Automatic Updates
----------------------------------
Watchtower is included to automatically monitor and update Docker containers when new images are available.

**Configuration:**
- **Schedule**: Updates run daily at 4:30 AM (configurable via `WATCHTOWER_SCHEDULE`)
- **Cleanup**: Automatically removes old images after updates
- **Notifications**: Optional notifications can be configured

**To configure notifications:**
1. Edit `media-server.env`
2. Set `WATCHTOWER_NOTIFICATIONS=shoutrrr` 
3. Set `WATCHTOWER_NOTIFICATION_URL` to your notification service URL

**Supported notification services:**
- Discord: `discord://token@id`
- Email: `smtp://username:password@host:port/?from=fromAddress&to=toAddress`
- Slack: `slack://[botname@]webhookurl`

**Note**: Watchtower itself is excluded from updates to prevent self-update issues.


![Shoutrrr](https://github.com/containrrr/shoutrrr/raw/main/docs/shoutrrr-logotype-horizontal.png)Shoutrrr - Notification Service
-----------------------------
Shoutrrr provides a unified notification service that can send messages to various platforms and services. It's integrated with Watchtower and can be used by other services for centralized notifications.

**Available at**: http://localhost:30086/

**Configuration:**
1. The service creates a default config file at `/opt/media-server/shoutrrr/config/config.yaml`
2. Edit the config file to add your notification services

**Supported Services:**
- **Discord**: `discord://token@channel_id`
- **Slack**: `slack://webhook_url`
- **Telegram**: `telegram://token@chat_id`
- **Email (SMTP)**: `smtp://username:password@host:port/?from=sender@example.com&to=recipient@example.com`
- **Gotify**: `gotify://gotify.example.com/token`
- **Matrix**: `matrix://username:password@homeserver/?rooms=room_id`
- **Teams**: `teams://webhook_url`
- **Pushover**: `pushover://shoutrrr:token@user_key`
- **And many more...**

**Example config.yaml:**
```yaml
urls:
  - discord://your_token@your_channel_id
  - smtp://user:pass@smtp.gmail.com:587/?from=sender@gmail.com&to=recipient@gmail.com
```

**Usage with other services:**
- Watchtower automatically uses Shoutrrr when `WATCHTOWER_NOTIFICATIONS=shoutrrr`
- Other services can send HTTP POST requests to `http://shoutrrr:8080/send` with message content


Enjoy
-----
- **Plex**: http://localhost:30080/web/
- **Overseerr**: http://localhost:30085/
- **Jellyseerr**: http://localhost:30087/
- **Sonarr**: http://localhost:30081/
- **Radarr**: http://localhost:30082/
- **Bazarr**: http://localhost:30083/
- **SABnzbd**: http://localhost:30084/